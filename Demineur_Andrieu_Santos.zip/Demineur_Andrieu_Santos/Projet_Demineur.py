#!/usr/bin/env python
# coding: utf-8

# In[2]:


from tkinter import *
import random

# Permet de choisir parmis 3 niveaux
def niveau():
    global nb_colonne, nb_ligne, nb_mines 
    niveau = choix.get()
    if niveau == 1:
        nb_colonne, nb_ligne, nb_mines = 10, 8, 10 #niveau facile
    elif niveau == 2:
        nb_colonne, nb_ligne, nb_mines = 18, 14, 40 #niveau moyen  
    else:
        nb_colonne, nb_ligne, nb_mines = 24, 20, 99 #niveau difficile

    cnv.configure(width=(nb_colonne*dim) , height=(nb_ligne*dim)) #Taille de la fenêtre
    jeu()


# Dessine la grille de jeu
def grille(nb_colonne, nb_ligne, dim):
    x1=0
    y1=0
    y2=dim*nb_ligne #Largeur
    x2=dim*nb_colonne #Hauteur
    colonne=0
    while colonne <= nb_colonne:
        colonne=colonne+1
        cnv.create_line(x1,y1,x1,y2, fill="black", width=1) 
        x1=x1+dim
    ligne=0
    while ligne <= nb_ligne:
        ligne=ligne+1
        cnv.create_line(0,y1,x2,y1, fill="black", width=1) 
        y1=y1+dim 

    
def jeu():
    global etat_partie #Permet de gérer le jeu lorqu'on perd ou gagne
    etat_partie = True
     
    # Initialisation des 2 tableaux avec des chaines vides
    y=0
    while y < nb_ligne:
        x=1
        y+=1
        while x <= nb_colonne:
            tab_m[x,y]=0 #tableau des mines
            tab_j[x,y]="" #tableau de jeu
            cnv.create_rectangle((x-1)*dim,(y-1)*dim, x*dim,y*dim,width=0, fill="white")
            x += 1 
    grille(nb_colonne, nb_ligne, dim) #Dessine la grille
    
    # placement aléatoire des mines
    nb_mines_voisines = 0
    while nb_mines_voisines < nb_mines:
        colonnebis = random.randint(1, nb_colonne)
        lig = random.randint(1, nb_ligne)
        if tab_m[colonnebis, lig] != 9:
            tab_m[colonnebis, lig] = 9 
            nb_mines_voisines = nb_mines_voisines + 1

    
def affiche_nb_mines(nb_mines_voisines, colonnebis, lig):
    coul = ['blue','orange','red','green','cyan','skyblue','pink']
    cnv.create_text(colonnebis*dim-dim//2, lig*dim-dim//2, text=str(nb_mines_voisines), fill=coul[nb_mines_voisines-1],font='Times')
            
# nombres de mines adjacentes
def nb_mines_adj(colonnebis, ligne):
    if colonnebis > 1:
        min_colonne = colonnebis - 1
    else:
        min_colonne = 1
    if colonnebis < nb_colonne:
        max_colonne = colonnebis + 1
    else:
        max_colonne = colonnebis       
    if ligne > 1:
        min_ligne = ligne - 1
    else:
        min_ligne = 1
    if ligne < nb_ligne:
        max_ligne = ligne + 1
    else:
        max_ligne = nb_ligne
    txtinfo = ""
    nb_mines = 0
    indice_ligne = min_ligne
    while indice_ligne <= max_ligne:
        indice_colonne = min_colonne
        while indice_colonne <= max_colonne:
            if tab_m [indice_colonne,indice_ligne] == 9:
                nb_mines += 1       
            indice_colonne = indice_colonne + 1      
        indice_ligne = indice_ligne +1
    return nb_mines


# Permet d'afficher toutes les cases voisines
def clear_voisins(colonnebis, ligne):
    global nb_mines_cachees, nb_cases_vues
    # si on a déjà la cellule n'est pas vide
    if tab_j[colonnebis, ligne] != 0:
        cnv.create_rectangle((colonnebis-1)*dim+3, (ligne-1)*dim+3, colonnebis*dim-3, ligne*dim-3, fill="grey")
        tab_j[colonnebis, ligne] = 0 # On met 0 dans le tableau de jeu
        nb_cases_vues = nb_cases_vues + 1
        
        # Vérification des cases voisines(gauche/droite/haut/bas)
        if colonnebis > 1:
            nb_mines_voisines = nb_mines_adj(colonnebis-1, ligne)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis-1, ligne)
            else:
                affiche_nb_mines(nb_mines_voisines, colonnebis-1, ligne)
        if colonnebis < nb_colonne:
            nb_mines_voisines = nb_mines_adj (colonnebis+1, ligne)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis+1, ligne)
            else:
                affiche_nb_mines(nb_mines_voisines, colonnebis+1, ligne)
        if ligne > 1:
            nb_mines_voisines = nb_mines_adj (colonnebis, ligne-1)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis, ligne-1)
            else:
                affiche_nb_mines(nb_mines_voisines, colonnebis, ligne-1)
        if ligne < nb_ligne:
            nb_mines_voisines = nb_mines_adj (colonnebis, ligne+1)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis, ligne+1)
            else:
                affiche_nb_mines (nb_mines_voisines, colonnebis, ligne+1)
                
        # Vérification des cases en diagonales
        if colonnebis > 1 and ligne > 1:
            nb_mines_voisines = nb_mines_adj(colonnebis-1, ligne-1)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis-1, ligne-1)
            else:
                affiche_nb_mines(nb_mines_voisines, colonnebis-1, ligne-1)
        if colonnebis > 1 and ligne < nb_ligne:
            nb_mines_voisines = nb_mines_adj(colonnebis-1, ligne+1)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis-1, ligne+1)           
            else:
                affiche_nb_mines(nb_mines_voisines, colonnebis-1, ligne+1)
        if colonnebis < nb_colonne and ligne > 1:
            nb_mines_voisines = nb_mines_adj(colonnebis+1, ligne-1)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis+1, ligne-1)
            else:
                affiche_nb_mines (nb_mines_voisines, colonnebis+1, ligne-1)
        if colonnebis < nb_colonne and ligne < nb_ligne:
            nb_mines_voisines = nb_mines_adj(colonnebis+1, ligne+1)
            if nb_mines_voisines == 0:
                clear_voisins(colonnebis+1, ligne+1)
            else:
                affiche_nb_mines(nb_mines_voisines, colonnebis+1, ligne+1)
       


def perdu():
    global etat_partie
    etat_partie  = False
    # Parcours du tableau
    nligne = 0
    while nligne < nb_ligne:
        ncolonne = 1
        nligne = nligne +1
        while ncolonne <= nb_colonne:
            # affichage de la grille
            if tab_m[ncolonne, nligne] == 9:
                if tab_j[ncolonne, nligne] == "?":
                    cnv.create_image(ncolonne*dim-dim//2, nligne*dim-dim//2, image = image_mine)
                elif tab_j[ncolonne, nligne] == "":
                    cnv.create_image(ncolonne*dim-dim//2, nligne*dim-dim//2, image = image_mine)
            else :
                if tab_j[ncolonne, nligne] == "d":
                    cnv.create_image(ncolonne*dim-dim//2, nligne*dim-dim//2, image = image_erreur)
            ncolonne = ncolonne+1
    cnv.create_text((nb_colonne/2)*dim-15, (nb_ligne/2)*dim-5, text='Perdu', fill='red', font='Times 100')


def gagne():
    cnv.create_text((nb_colonne/2)*dim-15, (nb_ligne/2)*dim-5, text='Gagné', fill='green', font='Times 100')


#Clic gauche
def pointeurG(event):
    global nb_cases_vues
    #Bloque le jeu si la partie est terminée
    if etat_partie :
        ncolonne = (event.x) // dim +1
        nligne = (event.y) // dim +1 
        # si la cellule est vide
        if tab_j[ncolonne, nligne] == "":
            # Si on est bien dans le tableau
            if ncolonne>=1 and ncolonne<=nb_colonne and nligne>=1 and nligne<=nb_ligne:
                # Si la cellule contient une mine
                if (tab_m[ncolonne, nligne] == 9):
                    perdu()
                else:
                    nb_mines_voisines = nb_mines_adj(ncolonne, nligne )
                    if nb_mines_voisines >= 1:
                        affiche_nb_mines(nb_mines_voisines, ncolonne, nligne ) 
                       
                    else: # Cases vides
                        clear_voisins(ncolonne, nligne)


# Clic droit
def pointeurD(event):
    global nb_mines_cachees, nb_cases_vues
    # Bloque le jeu si la partie est terminée
    if etat_partie :
        ncolonne = (event.x)// dim+1
        nligne = (event.y) // dim+1
        # Si c'est vide
        if tab_j[ncolonne, nligne]=="":
            # Affiche le drapeau
            cnv.create_image(ncolonne*dim-dim//2, nligne*dim-dim//2, image = image_flag)
            tab_j[ncolonne, nligne]="d"
            nb_cases_vues = nb_cases_vues + 1
            nb_mines_cachees = nb_mines_cachees - 1
        # Si ça contient  un drapeau    
        elif tab_j[ncolonne, nligne] == "d":
            # Remise à 0
            cnv.create_rectangle((ncolonne-1)*dim+3,(nligne-1)*dim+3, ncolonne*dim-3,nligne*dim-3,width=0, fill="white")
            # Affiche le ?
            cnv.create_text(ncolonne*dim-dim//2, nligne*dim-dim//2, text="?", fill='black',font='Times')
            tab_j[ncolonne, nligne] = "?"
            # Case non actionné car présence ?
            nb_cases_vues = nb_cases_vues - 1
            # Ajoute une mine après ?
            nb_mines_cachees = nb_mines_cachees + 1
        # Si la cellule contient un ?
        elif tab_j[ncolonne, nligne] == "?":
            # Remise à blanc
            cnv.create_rectangle((ncolonne-1)*dim+3,(nligne-1)*dim+3, ncolonne*dim-3,nligne*dim-3, width=0, fill="white")
            # Stocke du vide dans le tableau de jeu  
            tab_j[ncolonne, nligne] = ""



   
fen=Tk()

#Images 
image_mine = PhotoImage(file = "mine.png")
image_erreur = PhotoImage(file = "perdu.png")
image_flag = PhotoImage(file = "flag.png")
tab_m = {} # tableau des mines
tab_j = {} # tableau des cases modifiées par le joueur

#Déclarations de variables importantes
nb_colonne=0
nb_ligne=0
nb_mines=0
nb_mines_cachees=0
nb_cases_vues=0
dim=40

cnv=Canvas(fen, width=(nb_colonne*dim), height=(nb_ligne*dim))
cnv.bind("<Button-1>",pointeurG)
cnv.bind("<Button-3>",pointeurD)
cnv.pack(side=RIGHT)

# Bouton pour recommencer
fenetre1 = Frame(fen)
boutton1 = Button(fenetre1, text="Nouvelle partie", font="Tmes 15", width=20, command=jeu)
boutton1.pack()
fenetre1.pack()

# Bouton pour choix niveaux
fenetre2 = Frame(fen)
choix=IntVar()
choix.set(1)
case1=Radiobutton(fenetre2)
case1.configure(text='Facile', command=niveau, variable=choix, value=1)
case1.pack()
case2=Radiobutton(fenetre2)
case2.configure(text='Moyen', command=niveau, variable=choix, value=2)
case2.pack()
case3=Radiobutton(fenetre2)
case3.configure(text='Difficile', command=niveau, variable=choix, value=3)
case3.pack()
fenetre2.pack()


jeu()
niveau()
fen.mainloop()


# In[ ]:




