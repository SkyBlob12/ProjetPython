Bonjour,

Toutes les fonctionnalitées de bases n'ont pas pû être réalisé à terme. Le jeu reste néanmoins jouable.
Je tenais à prévenir, pour être totalement transparent, que du code à été inspiré de forums sur internet et de camarades à qui j'ai demandé de l'aide,
il risque d'y avoir des morceaux de codes similaires.

Merci
